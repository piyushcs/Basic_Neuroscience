import matplotlib.pyplot as plt
import numpy as np
import scipy.stats as stats
import math

mu = [5, 7]
sigma = [0.5, 1]
x = np.linspace(mu[0] - 3*sigma[0], mu[0] + 3*sigma[0], 100)
y = np.linspace(mu[1] - 3*sigma[1], mu[1] + 3*sigma[1], 100)
plt.plot(x, stats.norm.pdf(x, mu[0], sigma[0]))
plt.plot(y, stats.norm.pdf(y, mu[1], sigma[1]))
plt.show()
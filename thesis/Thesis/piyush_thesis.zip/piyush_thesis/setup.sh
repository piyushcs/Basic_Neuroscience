#!/bin/sh

setup_files=/root/files
mkdir -p $setup_files
LOG=/tmp/klogs

errorExit() {
    echo "*** $*" 1>&2
    exit 1
}

kube_proxy() {

    cd $setup_files

    kubectl get configmap -n kube-system kube-proxy -o yaml > kube-proxy-cm.yaml
    sed -i "s#server:.*#server: https://$VIP:6443#g" kube-proxy-cm.yaml
    kubectl apply -f kube-proxy-cm.yaml --force >> $LOG
    kubectl delete pod -n kube-system -l k8s-app=kube-proxy >> $LOG
}

# creating etcd cluster with chosen nodes
prereq_init() {
    echo "Multi-master kubeadm setup start" > $LOG
    node1=$1
    node2=$2
    node3=$3
    export ETH
    export VIP
    ip addr show $ETH > /dev/null 2>&1
    [[ $? -eq 0 ]] || errorExit "no interface named ${ETH}"

    export PRIVATE_IP=$(ip addr show ${ETH} 2> /dev/null | grep inet | head -1 | awk '{print $2}' | awk -F/ '{print $1}')

    if [ -z "$PRIVATE_IP" ]; then
        errorExit "no ip found at interface", $ETH
    fi

    echo "nodes given:" $node1, $node2, $node3>> $LOG

    cd $setup_files

    echo "Node IP: " $PRIVATE_IP >> $LOG
    echo "Creating docker compose file for etcd and keepalived " >> $LOG

cat >prereq.yaml <<EOF
version: '2'
services:
    etcd:
        image: gcr.io/google_containers/etcd-amd64:3.1.12
        container_name: etcd
        volumes:
        - /var/lib/etcd:/var/lib/etcd
        ports:
        - 2380:2380
        - 2379:2379
        network_mode: host
        restart: always
        command: ["sh", "-c", "etcd --name=$PRIVATE_IP \
            --advertise-client-urls=http://$PRIVATE_IP:2379 \
            --listen-client-urls=http://$PRIVATE_IP:2379 \
            --initial-advertise-peer-urls=http://$PRIVATE_IP:2380 \
            --listen-peer-urls=http://$PRIVATE_IP:2380 \
            --initial-cluster-token=9477af68bbee1b9ae037d6fd9e7efefd \
            --initial-cluster=$node1=http://$node1:2380,$node2=http://$node2:2380,$node3=http://$node3:2380 \
            --initial-cluster-state=new \
            --data-dir=/var/lib/etcd"]
    keepalived:
        image: veritas/flexsnap-kubeha:3.0.9999
        container_name: keepalived
        environment:
            - ETH
            - VIP
        network_mode: host
        cap_add:
            - NET_ADMIN
        restart: always
EOF

cat >kubeadm-config.yaml <<EOF
apiVersion: kubeadm.k8s.io/v1alpha1
kind: MasterConfiguration
kubernetesVersion: v1.9.1
etcd:
    endpoints:
    - http://${node1}:2379
    - http://${node2}:2379
    - http://${node3}:2379
networking:
    podSubnet: 10.244.0.0/16
apiServerCertSANs:
- $VIP
apiServerExtraArgs:
    apiserver-count: "3"
EOF

    modprobe ip_vs
    [[ $? -eq 0 ]] || errorExit "module ip_vs unable to load"

    echo "Starting etcd" >> $LOG 
    docker-compose --file prereq.yaml up -d >> $LOG 2>&1
    [[ $? -eq 0 ]] || errorExit "etcd/keepalived statup failed, check etcd.yaml"
}

primary_init() {
    cd $setup_files

    printf "Starting kubeadm on ${HOSTNAME} - " >> $LOG
    kubeadm init --config=kubeadm-config.yaml >> $LOG 2>&1 
    [[ $? -eq 0 ]] || errorExit "primary master statup failed, check kubelet status, kubeadm-config.yaml, klogs"  

    rm -rf ~/.kube
    mkdir -p $HOME/.kube; sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config; sudo chown $(id -u):$(id -g) $HOME/.kube/config
    echo "done" >> $LOG

    echo "Install network plugin" >> $LOG
    kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/v0.9.1/Documentation/kube-flannel.yml >> $LOG 2>&1

    [[ $? -eq 0 ]] || errorExit "flannel installation failed, check kubectl status"

    echo "Install Persistent Storage" >> $LOG
    kubectl create -f /root/flexsnap-syncvol.yaml >> $LOG 2>&1

    [[ $? -eq 0 ]] || errorExit "Persistent Storage startup failed"

    #sed -i "s#server:.*#server: https://$VIP:6443#g" /etc/kubernetes/kubelet.conf
    #systemctl restart kubelet
}

secondary_init() {
    PRIMARY=$1

    count=0
    while [[ count -ne 10 ]]; do
        rsync -art --update rsync://$PRIMARY/ca/ >> $LOG 2>&1
        [[ $? -eq 0 ]] && break

        let "count++"
        sleep 3
    done

    rsync -art --update rsync://$PRIMARY/ca/ >> $LOG 2>&1
    [[ $? -eq 0 ]] || errorExit "primary master certs not available, rsync failed"

    rsync -art --update rsync://$PRIMARY/ca/ca.crt /etc/kubernetes/pki >> $LOG 2>&1
    rsync -art --update rsync://$PRIMARY/ca/ca.key /etc/kubernetes/pki >> $LOG 2>&1
    rsync -art --update rsync://$PRIMARY/ca/sa.pub /etc/kubernetes/pki >> $LOG 2>&1
    rsync -art --update rsync://$PRIMARY/ca/sa.key /etc/kubernetes/pki >> $LOG 2>&1

    [[ $? -eq 0 ]] || errorExit "certificate copy failed, check rsync status"

    cd /etc/kubernetes/pki
    if [ -f ca.crt ] && [ -f ca.key ] && [ -f sa.pub ] && [ -f sa.key ]; then
        printf "Starting kubeadm on ${HOSTNAME} -> " >> $LOG
        kubeadm init --config=$setup_files/kubeadm-config.yaml >> $LOG 2>&1

        [[ $? -eq 0 ]] || errorExit "secondary master addition failed, check kubelet status, time of systems, kubeadm-config.yaml, klogs"
        rm -rf ~/.kube
        mkdir -p $HOME/.kube; sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config; sudo chown $(id -u):$(id -g) $HOME/.kube/config
        echo "done" >> $LOG
    else
        errorExit "certificates are not available"
    fi

    #sed -i "s#server:.*#server: https://$VIP:6443#g" /etc/kubernetes/kubelet.conf
    #systemctl restart kubelet
}

load_balancer() {
    sed -i "s#server:.*#server: https://$VIP:6443#g" /etc/kubernetes/kubelet.conf
    systemctl restart kubelet
}

ETH=`cat /opt/veritas/cloudpoint/predeploy/etc/predeploy.json | python -c "import sys, json; print json.load(sys.stdin)['ethlinklocal']"`
VIP=169.254.7.70

echo $ETH, $VIP

op=$1

shift

case "$op" in
    prereq)
        prereq_init $*
        ;;
    primary)
        primary_init $*
        ;;
    secondary)
        secondary_init $*
        ;;
    proxy)
	kube_proxy $*
	;;
    worker)
	load_balancer $*
	;;
    *)
        exit 1
esac
exit 0

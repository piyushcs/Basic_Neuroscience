#!/bin/sh

cat >syncvol.txt <<EOF
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Aliquam malesuada bibendum arcu vitae elementum. Ut tortor pretium viverra suspendisse potenti nullam. Ullamcorper sit amet risus nullam eget felis. Ut venenatis tellus in metus vulputate. Mattis enim ut tellus elementum. Sed ullamcorper morbi tincidunt ornare. Aliquam ultrices sagittis orci a scelerisque purus. Non curabitur gravida arcu ac tortor dignissim convallis aenean. Vulputate dignissim suspendisse in est ante in nibh mauris cursus. A diam maecenas sed enim ut sem viverra. Fermentum dui faucibus in ornare quam viverra orci.

Ante in nibh mauris cursus. Faucibus purus in massa tempor nec feugiat nisl pretium fusce. Ultrices sagittis orci a scelerisque purus. Id eu nisl nunc mi ipsum faucibus vitae aliquet. Elementum nibh tellus molestie nunc non. Lorem ipsum dolor sit amet. Sit amet consectetur adipiscing elit ut aliquam purus. Mauris nunc congue nisi vitae suscipit tellus mauris a diam. Augue ut lectus arcu bibendum at varius vel pharetra vel. Lectus magna fringilla urna porttitor. Eget nulla facilisi etiam dignissim diam. In ornare quam viverra orci sagittis eu volutpat odio facilisis. Ac turpis egestas integer eget aliquet nibh praesent tristique. Est lorem ipsum dolor sit amet. Neque aliquam vestibulum morbi blandit cursus risus at. Feugiat in ante metus dictum at. Non pulvinar neque laoreet suspendisse interdum consectetur libero. Tincidunt arcu non sodales neque sodales. Sagittis orci a scelerisque purus semper eget duis. Odio euismod lacinia at quis risus sed.

Porttitor massa id neque aliquam vestibulum morbi blandit cursus risus. Odio euismod lacinia at quis. Nisi porta lorem mollis aliquam ut porttitor leo a diam. In metus vulputate eu scelerisque felis imperdiet proin fermentum. Fermentum leo vel orci porta non. Venenatis a condimentum vitae sapien pellentesque habitant morbi tristique senectus. Quisque id diam vel quam elementum pulvinar etiam non. Mattis pellentesque id nibh tortor id aliquet lectus proin. Justo donec enim diam vulputate ut. Elementum pulvinar etiam non quam lacus suspendisse faucibus. Cursus in hac habitasse platea dictumst quisque sagittis purus. Massa vitae tortor condimentum lacinia quis vel eros donec ac. Sit amet massa vitae tortor condimentum lacinia quis. Sagittis nisl rhoncus mattis rhoncus urna neque viverra. Viverra maecenas accumsan lacus vel facilisis volutpat. Odio morbi quis commodo odio aenean sed adipiscing diam donec. Iaculis urna id volutpat lacus laoreet non curabitur gravida arcu.

A iaculis at erat pellentesque adipiscing. Nascetur ridiculus mus mauris vitae ultricies leo integer. Euismod nisi porta lorem mollis. Dui nunc mattis enim ut tellus elementum sagittis vitae et. Cursus risus at ultrices mi tempus imperdiet nulla. Massa sapien faucibus et molestie ac feugiat. Volutpat diam ut venenatis tellus in metus vulputate eu scelerisque. Id diam maecenas ultricies mi eget mauris pharetra. Vulputate ut pharetra sit amet aliquam id diam. Urna id volutpat lacus laoreet non. Tristique senectus et netus et. Nunc faucibus a pellentesque sit amet porttitor. Felis donec et odio pellentesque diam. Turpis nunc eget lorem dolor sed viverra ipsum nunc. Velit dignissim sodales ut eu sem integer vitae. Id faucibus nisl tincidunt eget nullam. Aenean vel elit scelerisque mauris pellentesque pulvinar. Praesent tristique magna sit amet purus.

Consequat semper viverra nam libero justo laoreet sit. Viverra ipsum nunc aliquet bibendum enim facilisis. Malesuada bibendum arcu vitae elementum curabitur. Interdum varius sit amet mattis vulputate enim nulla aliquet porttitor. Magna fermentum iaculis eu non diam phasellus vestibulum lorem sed. Accumsan tortor posuere ac ut. Morbi blandit cursus risus at ultrices. Iaculis eu non diam phasellus. Interdum velit laoreet id donec ultrices tincidunt. Ultricies lacus sed turpis tincidunt id aliquet. Curabitur vitae nunc sed velit. Vestibulum lectus mauris ultrices eros in cursus turpis. Eu non diam phasellus vestibulum lorem. Orci nulla pellentesque dignissim enim sit amet venenatis urna cursus. Etiam non quam lacus suspendisse faucibus interdum posuere lorem.
EOF

# cleanup
rm -rf /vx/global/syncvol.txt

cp syncvol.txt /vx/global
sleep 10

checksum=`cksum syncvol.txt | awk '{print $1}'`
echo "Original Checksum: ", $checksum
rm -rf dwnd_files
mkdir dwnd_files

x="$1 $2 $3 $4"

for i in $x
do
	rsync -art rsync://$i/pv/syncvol.txt dwnd_files/$i
	chksum_dwnd=`cksum dwnd_files/$i | awk '{print $1}'`
	echo $i, " Syncvol checksum: ", $chksum_dwnd
done
